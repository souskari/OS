#ifndef USERPROG_SYSCALL_H
#define USERPROG_SYSCALL_H

#include "lib/kernel/list.h"
#include "lib/user/syscall.h"


void syscall_init (void);
struct file_struct{
	struct file* current_file;
	int fd;
	struct list_elem file_elem;
};

#endif /* userprog/syscall.h */
