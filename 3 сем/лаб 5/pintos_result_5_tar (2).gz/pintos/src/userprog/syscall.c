#include <syscall-nr.h>
#include "threads/synch.h"
#include "userprog/syscall.h"
#include <stdio.h>
#include "threads/interrupt.h"
#include "threads/thread.h"
#include "threads/init.h"
#include "threads/vaddr.h"
#include "devices/shutdown.h"
#include "devices/input.h"
#include "filesys/filesys.h"
#include "userprog/pagedir.h"
#include "userprog/process.h"
#include "threads/malloc.h"
#include <string.h>
#include <stdbool.h>
#include "lib/user/syscall.h"
#include "filesys/file.h"


int validate_user_pointer(void* addr);
static void syscall_handler(struct intr_frame*);
int* args;

void syscall_init(void)
{
    intr_register_int(0x30, 3, INTR_ON, syscall_handler, "syscall");
}

static void
syscall_handler(struct intr_frame* f) {
	int* nr;
	nr = (int*)f->esp; 
	if (!validate_user_pointer(nr)) {
		thread_current()->code_for_exiting = -1;
		thread_exit();
		return;
	} 

	args = (int*)f->esp + 1; 
	struct list_elem* filesize_el;


    switch (*nr) {
    
    case SYS_HALT: 
        shutdown_power_off();
        break;
    case SYS_EXIT: 
        thread_current()->code_for_exiting = args[0];
        thread_exit();
        break;
    case SYS_CREATE:

	if (!validate_user_pointer(args[0])) {
            thread_current()->code_for_exiting = -1;
            f->eax = -1;
            thread_exit();
            
        }
        if ((char**)args[0] == NULL) {
            thread_current()->code_for_exiting = -1;
            thread_exit();
            
        }
        f->eax = filesys_create((char**)args[0], args[1]);
	break;
    case SYS_REMOVE:

        if (!validate_user_pointer(args[0])) {
            thread_current()->code_for_exiting = -1;
            thread_exit();
            f->eax = -1;
        }
        f->eax = filesys_remove((char**)args[0]);
	break;
    case SYS_OPEN:
	f->eax=-1;
	if (!validate_user_pointer(args[0])) {
            thread_current()->code_for_exiting = -1;
            thread_exit();
        }
        if ((char**)args[0] == NULL) {
            thread_current()->code_for_exiting = -1;
            thread_exit();
            
        }
        struct file* FILE = filesys_open((char**)args[0]);
        if (FILE == NULL) return -1;
        
	struct file_struct* new_file = malloc(sizeof(struct file_struct));
	new_file->fd = thread_current()->cnt_for_des;
	new_file->current_file = FILE;
        f->eax = thread_current()->cnt_for_des;
        thread_current()->cnt_for_des++;
        list_push_back(&thread_current()->open_files, &new_file->file_elem);
	break;
    case SYS_CLOSE:
        if (list_empty(&thread_current()->open_files)){
            thread_current()->code_for_exiting = -1;
            thread_exit();
            break;
        }
        if (args[0] == STDIN_FILENO || args[0] == STDOUT_FILENO) {
            thread_current()->code_for_exiting = -1;
            thread_exit();
            break;
            
        }
        
        struct list_elem* e = list_begin(&thread_current()->open_files);
        for (e; e != list_end(&thread_current()->open_files); e = list_next(e)) {
            struct file_struct* tmp = list_entry(e, struct file_struct, file_elem);
            if (tmp->fd == args[0]) {
            	file_close(tmp->current_file);
        	list_remove(e);
        	thread_current()->cnt_for_des--;
                break;
            }
        }
        break;
   case SYS_FILESIZE: 
        filesize_el = list_begin(&thread_current()->open_files);
        for (filesize_el; filesize_el != list_end(&thread_current()->open_files); filesize_el = list_next(filesize_el)) {
            struct file_struct* tmp_size = list_entry(filesize_el, struct file_struct, file_elem);
            if (tmp_size->fd == args[0]) {
            	f->eax = file_length(tmp_size->current_file);
                break;
                //thread_exit();
            }
        }
	break;

   case SYS_READ:
   	if (!validate_user_pointer((char**)args[1])) {
            thread_current()->code_for_exiting = -1;
            thread_exit();
            break;
        }
   	if(args[0] == STDIN_FILENO){
   		f->eax=input_getc();
   	}
   	if(!list_empty(&thread_current()->open_files)){
	   	struct list_elem* fileread_el = list_begin(&thread_current()->open_files);
		for (fileread_el; fileread_el != list_end(&thread_current()->open_files); fileread_el = list_next(fileread_el)) {
		    struct file_struct* tmpr = list_entry(fileread_el, struct file_struct, file_elem);
		    if (tmpr->fd == args[0]) {
		    	f->eax = file_read(tmpr->current_file, (char**)args[1], args[2]);
		        break;
		        //thread_exit();
		    }
		}
   		
   	}
   	
   	break;
    case SYS_WRITE:
   	if (!validate_user_pointer((char**)args[1])) {
            thread_current()->code_for_exiting = -1;
            thread_exit();
        }
   	if(args[0] == STDOUT_FILENO){
   		putbuf(((const char**)f->esp)[2], ((size_t*)f->esp)[3]);
   	}
   	if(args[0] == STDIN_FILENO){
   		return -1;
   	}
    	struct list_elem* filewrite_el = list_begin(&thread_current()->open_files);
	for (filewrite_el; filewrite_el != list_end(&thread_current()->open_files); filewrite_el = list_next(filewrite_el)) {
	    struct file_struct* tmpr = list_entry(filewrite_el, struct file_struct, file_elem);
	    if (tmpr->fd == args[0]) {
	    	f->eax = file_write(tmpr->current_file, (char**)args[1], args[2]);
	        break;
	        //thread_exit();
	    }
	}
	break;
   case SYS_WAIT:
	if (!validate_user_pointer(nr)) return -1;
        f->eax = process_wait((tid_t)args[0]);
	break;
    case SYS_EXEC:
        if (!validate_user_pointer(args[0])) return -1;
        f->eax = process_execute((char**)args[0]);
        
	break;	
    }

     
}
int validate_user_pointer(void* addr) {
    if (!is_user_vaddr(addr) || !pagedir_get_page(thread_current()->pagedir, addr)) {
        return 0;
    }
    else {
        return 1;
    }
}
